package u1.entregable1;

import java.util.Scanner;

public class Ej3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int precioBase = 3;
				int precioGourmet = 5;
				int cantHambuerguesas;
				int diaDeLaSemana;
				int precioBasico = 3;
				int precioTotal = 0;
				double descuento;
				int descuentoFanegas = 12;
				
				System.out.println("¿Cuantas hamburguesas queires pedir? ");
						cantHambuerguesas = sc.nextInt();
						
						System.out.println("¿que dia de la semana esta realizando el pedido?  (1: lunes 2: martes 3: miercoles 4:jueves 5:viernes 6:sabado 7:domingo)");
							diaDeLaSemana = sc.nextInt();
							
							if (diaDeLaSemana == 2) {
								
								if (cantHambuerguesas >=2) {
									precioTotal = (cantHambuerguesas / 2) * 9 +(cantHambuerguesas % 2) * precioGourmet;
								}else {
									precioTotal = cantHambuerguesas * precioGourmet;
								}
							}else if (diaDeLaSemana == 3) {
								precioTotal = cantHambuerguesas * 2;
							}else {
								System.out.print("Perteneces al club Fanegas de Burbur? (Si/No) ");
									String respuestaClub = sc.next();
									if (respuestaClub.equalsIgnoreCase("Si")) {
										descuento = (double) descuentoFanegas / 100;
									precioTotal = (int) (cantHambuerguesas * precioBasico * (1 - descuento));
							} else {
								precioTotal = cantHambuerguesas * precioBasico;
								}
									
							}
							System.out.println("El precio total del pedido es: " + precioTotal + "€.");
	}
}
