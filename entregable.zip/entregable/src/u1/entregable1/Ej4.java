package u1.entregable1;

import java.util.Scanner;

public class Ej4 {

	public static void main(String[] args) {
		
		int altura;
		int i;
		int j;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Inroduce la altura");
			altura = sc.nextInt();
			
			for (i = 1; i <= altura; i++) {
				for ( j = 1; j <= altura; j++) {
					if (i == 1 && j == altura) {
						System.out.print("*");
						
					}else if (i == altura && j <= altura) {
						System.out.print("*");
					}else if (i > 1 && i < altura && j == altura) {
						System.out.print("*");
					}else {
						System.out.print(" ");
					}
				}
				System.out.println();
			} 
	}

}
