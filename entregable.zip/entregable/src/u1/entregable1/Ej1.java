//Escribe un programa que solicite por consola números naturales pares hasta que la suma total de todos ellos sea mayor que la constante 100.
//Si el número introducido no es natural o no es par, debe indicarlo al usuario y solicitarlo de nuevo hasta que este introduzca un número que sea válido. 
//Al finalizar debe mostrar la media y el mayor de todos los números introducidos.

package u1.entregable1;

import java.util.Scanner;


public class Ej1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
			int sumaTotal = 0;
				int cantNumeros = 0;
				int numMayor = 0;
				int num;
				
				while (sumaTotal <= 100) {
					System.out.print("Introduce el numero natural par:");
					num = sc.nextInt();
					
					if (num % 2 == 0 && num > 0) {
						sumaTotal += num;
						cantNumeros++;
						
						if (num > numMayor) {
							numMayor = num;
						}
					} else {
						System.out.println("El numero introducido no es numero natural par valido.");
					}
			}
			double media = (double)	sumaTotal / cantNumeros;
			
			System.out.println("La suma total es mayor que la constante 100");
			
			System.out.println("Esta es la media de los numeros introducidos: " + media);
			
			System.out.println("El numero mayor introducido es: " + numMayor);
				
	}
	
}
