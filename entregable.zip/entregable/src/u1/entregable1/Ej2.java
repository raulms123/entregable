package u1.entregable1;

import java.util.Random;
import java.util.Scanner;

 class Ej2 {

	public static void main(String[] args) {
		
		int intento;
		int numeroDeUsuario;
		
		Random random = new Random();
		int numSecreto = random.nextInt(25) + 1; //paco esto es para generar un numero aleatorio entre 1 y 25
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Intenta adivinar el numero secreto jeje");
		System.out.println("¿En cuantos intentos quiere realizarlo?");
		int intentosMax = sc.nextInt();
		boolean ayuda = false;
		
		if(intentosMax <= 0) {
			System.out.println("El numero de intentos uqe quieras realizar debe ser mayor que cero");
			return;
		}
		
		System.out.println("¿Quieres algo de ayuda?) (Si/No): ");
		String respuestaAyuda = sc.next();
		if (respuestaAyuda.equalsIgnoreCase("Si")) {
		ayuda = true;
		}
		
		for (intento = 1; intento <= intentosMax; intento++) {
			System.out.println("Intento" + intento + ": Introduce tu numero: ");
			numeroDeUsuario = sc.nextInt();
			
			if (numeroDeUsuario < 1 || numeroDeUsuario > 25) {
				System.out.println("El numero ingresado no es valido");
				continue;
			}
			
			if(numeroDeUsuario == numSecreto) {
				System.out.println("!Bien! haz adivinado el nuemro secreto");
				System.out.println("numero de intentos realiados" + intento);
				break;
			}else {
				if (ayuda) {
					if (numeroDeUsuario < numSecreto) {
						System.out.println("El numero secreto es mayor");
					}else {
						System.out.println("El numero secreto es menor");
					}
					
				}
				
				if (intento == intentosMax) {
					System.out.println("Haz agotado todos tus intento, perdiste.");
				}else {
					System.out.println("Numero incorrecto. Numero de intentos restantes " +(intentosMax - intento));
				}
			}
		}
		
	}
	
}
